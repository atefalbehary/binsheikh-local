<?php

return [
    'booking_successfully_completed' => 'Booking Successfully Completed',
];
